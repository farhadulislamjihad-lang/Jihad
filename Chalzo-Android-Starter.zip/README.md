# Chalzo

Chalzo is a social video app concept focused on challenges, video sharing, likes, comments, follows and rankings.

## Current starter
- Android/Kotlin project
- Home screen
- Challenge button
- Ready to expand with login, video feed, upload, comments, follows and rankings

## Next features
1. Login/signup
2. Video feed
3. Upload video
4. Power/Cheer likes
5. Comments and follows
6. Challenge battles
7. Monthly ranking and prizes
