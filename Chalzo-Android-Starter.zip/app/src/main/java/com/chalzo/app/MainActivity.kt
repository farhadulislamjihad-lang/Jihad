package com.chalzo.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.challengeButton).setOnClickListener {
            findViewById<TextView>(R.id.statusText).text =
                "Challenge mode coming soon! 🏆"
        }
    }
}
